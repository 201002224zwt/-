package Entity;

public class paper {
}
