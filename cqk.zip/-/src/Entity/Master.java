package Entity;
import DAOS.DAOFactory;
import User.User;
import User.UserType;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * @author zhuwentao
 * @version 1.0
 * @data 2022/12/9
 */

public class Master extends User {
    private String sid;//ѧ��ѧ��
    private String name;//ѧ������
    private String menid;//������ʦ
    private String addmissiontime;//��ѧʱ��
    private int stype;//ѧ�����ͣ���ʿ�о�����˶ʿ�о�����

    public Master(UserType type, String loadname, String passwd, String sid, String name, String menid, String addmissiontime, int stype) {
        super(type, loadname, passwd);
        this.sid = sid;
        this.name = name;
        this.menid = menid;
        this.addmissiontime = addmissiontime;
        this.stype = stype;


    }

    public String getSid() {
        return sid;
    }

    public String getName() {
        return name;
    }

    public String getMenid() {
        return menid;
    }

    public String getAddmissiontime() {
        return addmissiontime;
    }

    public int getStype() {
        return stype;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMenid(String menid) {
        this.menid = menid;
    }

    public void setAddmissiontime(String addmissiontime) {
        this.addmissiontime = addmissiontime;
    }

    public void setStype(int stype) {
        this.stype = stype;
    }

    @Override
    public String toString() {
        return "Master{" +
                "sid='" + sid + '\'' +
                ", name='" + name + '\'' +
                ", subject=" + menid +
                ", addmissiontime='" + addmissiontime + '\'' +
                ", stype=" + stype +
                '}';
    }
    public  void  showCourseList(LinkedList<Course> courses,LinkedList<Choose>myChooses){

        Integer i=1;//�к�
        Iterator<Course> itr = courses.iterator();

        while (itr.hasNext()){
            Course course=itr.next();

            String stateString="δѡ����ѡ";

            Iterator<Choose> itr1 = myChooses.iterator();

            while (itr1.hasNext()){
                Choose choose= itr1.next();
                if(choose.getCouseid().equals(course.getCouseid())){
                    stateString="��ѡ�������ظ�ѡ";

                    break;
                }
            }


            System.out.println(i.toString()+"\t"+course.getCouseid()+"\t"+course.getName()+"\t"+course.getHours()+"\t"+course.getApplications()+"\t"+stateString);
            i++;
        }
    }


    public void chooseCourse(){
        String subid= DAOFactory.getMentorDAO().getMentor(this.menid).getSubid();

        //�鿴�Լ�ѧ�Ƶ��ض�״̬�Ŀγ��б�
        LinkedList<Course> courses= DAOFactory.getCourseDAO().getStateCourses(subid,1);

        LinkedList<Choose> myChooses=new LinkedList<>();


        LinkedList<Choose> allChooses = DAOFactory.getChooseDAO().getAllChooses();


       // System.out.println(allChooses.size());


        //�鿴����ѡ�μ�¼�����м����ǵ�ǰ˶ʿѡ��
        //Ĭ�����2
        Integer volAvailabe=2;
        Integer volAlready=0;

        Iterator<Choose> itr = allChooses.iterator();

        while (itr.hasNext()) {

            Choose choose=itr.next();
            System.out.println("---");

            //char array0[] =choose.getMid().toCharArray();//�滻�ַ����в��ɼ��ַ�

           // char array[]= this.sid.toCharArray();//�滻�ַ����в��ɼ��ַ�


            if (choose.getMid().trim().equals(this.sid)){
                myChooses.add(choose);
                volAvailabe--;
                volAlready++;
            }
        }


        System.out.println("���̿γ��б����£�");
        showCourseList(courses,myChooses);



        while (volAvailabe>0){
            System.out.println("��ǰ˶ʿ��ѡ��"+ volAlready.toString() +"��־Ը������ѡ��"+volAvailabe.toString()+"��־Ը");
            volAlready++;
            volAvailabe--;
            System.out.println("������Ҫѡ�Ŀγ��к�");
            int row;

            Scanner sc=new Scanner(System.in);
            row=sc.nextInt();
            Choose choose=new Choose(courses.get(row-1).getCouseid(),this.sid);
            myChooses.add(choose);
            DAOFactory.getChooseDAO().addChoose(choose);

            //չ�ֱ��˵���ѡ�γ��б� 1 �� 2 ��
            System.out.println("������ѡ�γ�����");
            Iterator<Choose> itr1 = myChooses.iterator();
            System.out.println("�γ̺�\t�γ���\t");
            while (itr1.hasNext()) {

                Choose tmp=itr1.next();
               Course course=DAOFactory.getCourseDAO().getCourse(tmp.getCouseid());
                System.out.println(course);
                System.out.println(course.getCouseid()+course.getName());
            }



            int res=0;
            while (res!=1&&res!=2&&volAvailabe>0){
                System.out.println("�Ƿ��������ѡ�μ�¼�� 1.�� 2.��");
                res=sc.nextInt();
                if(res==1){
                    break;
                }
                else if (res==2){
                    return;
                }
                else
                {
                    System.out.println("��������������1����2");
                }

            }
            System.out.println("���̿γ��б����£�");
            showCourseList(courses,myChooses);
        }
    }
    @Override
    public void menu() {

        while(true){
            System.out.println("--------------�о������ܲ˵�---------------");
            System.out.println("1.ѡ�����̿γ�");
            System.out.println("2.�˳�ϵͳ");
            System.out.println("��ѡ��");
            int choose;
            Scanner sc=new Scanner(System.in);
            choose=sc.nextInt();
            switch (choose){
                case 1:
                    //���Ի��ѧ���µ�state=1�Ŀγ�
                    //ͨ����ʦ��
                  chooseCourse();

                  break;

                case 2:
                    return;
            }
        }
    }
}