package DAOS;
import Entity.AcademicActivity;
import Entity.Master;

public class AcademicActivityDAOimp implements AcademicActivityDAO{

    @Override
    public void addAcademicActivity(AcademicActivity activity) {

    }

    @Override
    public void deleteAcademicActivity(AcademicActivity activity) {

    }

    @Override
    public void updateAcademicActivity(AcademicActivity activity) {

    }

    @Override
    public Master getAcademicActivity(String MasterId) {
        return null;
    }
}
