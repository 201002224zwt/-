package User;

import java.io.Serializable;

public  abstract  class  User implements Serializable{
    private static final long serialVersionUID = 1;
        UserType type;
        String loadname;//id
        String passwd;

    public  abstract void menu() ;

    public User(UserType type, String loadname, String passwd) {
            this.type = type;
            this.loadname = loadname;
            this.passwd = passwd;
        }
    }
