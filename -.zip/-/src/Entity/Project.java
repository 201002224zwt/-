package Entity;

public class Project {
}
