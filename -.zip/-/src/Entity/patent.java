package Entity;

public class patent {
}
