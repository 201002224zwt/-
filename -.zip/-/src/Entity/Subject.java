package Entity;

/**
 * @author caoqike
 * @date 2022-12-09 08:36:40
 */
public class Subject {
    public String subid;
    public String name;

    public Subject(String subid, String name) {
        this.subid = subid;
        this.name = name;
    }

}
