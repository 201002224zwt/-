package Entity;

/**
 * @author zhuwentao
 * @version 1.0
 * @data 2022/12/9
 */
public class  TutorTable{
//    couid mid
//    subid  tid  selfdescrible result
   // private String id;//课程号
    //private Teacher teacher;//教授课程教师
}