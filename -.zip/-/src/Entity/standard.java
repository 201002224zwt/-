package Entity;

public class standard {
}
