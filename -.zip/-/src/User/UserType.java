package User;

public enum UserType {
        Administrator,
        SubjectMaster,//学科负责人
        Teacher,//授课教师
        Master,
        Mentor,//导师
}

