package DAOS;

/**
 * @author Administrator
 * @version 1.0
 * @data 2022/12/10 9:20
 */
public interface MentorDAO {
}
